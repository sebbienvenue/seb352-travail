# LaTeX2HTML 2008 (1.71)
# Associate images original text with physical files.


1;

