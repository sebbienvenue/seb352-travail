# LaTeX2HTML 2008 (1.71)
# Associate images original text with physical files.


$key = q/sim;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$ \sim$">|; 

1;

