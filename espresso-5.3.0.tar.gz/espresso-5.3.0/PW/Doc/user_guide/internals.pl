# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/SubSec:badpara/;
$ref_files{$key} = "$dir".q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/pw2casino_info/;
$ref_files{$key} = "$dir".q|node12.html|; 
$noresave{$key} = "$nosave";

1;

