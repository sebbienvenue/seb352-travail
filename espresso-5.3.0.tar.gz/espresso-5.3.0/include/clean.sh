#!/bin/bash

\rm -f c_defs.h fft_defs.h >& /dev/null
